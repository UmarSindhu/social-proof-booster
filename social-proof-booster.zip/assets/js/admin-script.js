jQuery(document).ready(function($) {
    $('.spbp-color-picker').wpColorPicker();
});